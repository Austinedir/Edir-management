import os
from celery import Celery

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'edir_project.settings')
app = Celery('edir')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()
