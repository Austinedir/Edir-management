from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit
from .models import Announcement


class AnnouncementForm(forms.ModelForm):
    class Meta:
        model = Announcement
        fields = ['title', 'body', 'is_published']
        widgets = {'body': forms.Textarea(attrs={'rows': 5})}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.add_input(Submit('submit', 'Save Announcement', css_class='btn btn-primary'))
