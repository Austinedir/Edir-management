from django.urls import path
from apps.notifications import views

app_name = 'notifications'

urlpatterns = [
    path('', views.notification_list, name='list'),
    path('<uuid:pk>/read/', views.mark_read, name='mark_read'),
    path('announcements/', views.announcement_list, name='announcements'),
    path('announcements/new/', views.announcement_create, name='announcement_create'),
]
